document.addEventListener("DOMContentLoaded", function() {
    // Simulated user data and authentication
    const users = [
        { username: 'user1', password: 'pass1' },
        { username: 'user2', password: 'pass2' }
    ];
    let loggedInUser = null;

    // Login modal elements
    const loginNav = document.getElementById('login-nav');
    const loginModal = document.getElementById('login-modal');
    const closeBtn = document.getElementsByClassName('close-btn')[0];
    const loginForm = document.getElementById('login-form');

    loginNav.addEventListener('click', function() {
        loginModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', function() {
        loginModal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target == loginModal) {
            loginModal.style.display = 'none';
        }
    });

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        const user = users.find(user => user.username === username && user.password === password);

        if (user) {
            loggedInUser = user;
            loginModal.style.display = 'none';
            loginNav.textContent = Welcome, ${username};
            alert('Login successful!');
        } else {
            alert('Invalid username or password.');
        }
    });

    // Practice Tests
    const testContainer = document.getElementById('test-container');
    const practiceTests = [
        { id: 1, title: 'Math Test', questions: 20 },
        { id: 2, title: 'Science Test', questions: 15 },
        { id: 3, title: 'History Test', questions: 10 }
    ];

    practiceTests.forEach(test => {
        const testElement = document.createElement('div');
        testElement.className = 'test';
        testElement.innerHTML = 
            <h3>${test.title}</h3>
            <p>Number of questions: ${test.questions}</p>
            <button onclick="startTest(${test.id})">Start Test</button>
        ;
        testContainer.appendChild(testElement);
    });

    // Performance Analytics
    const analyticsContainer = document.getElementById('analytics-container');
    const analyticsData = {
        testsTaken: 10,
        averageScore: 85,
        timeSpent: '5 hours'
    };

    analyticsContainer.innerHTML = 
        <p>Tests Taken: ${analyticsData.testsTaken}</p>
        <p>Average Score: ${analyticsData.averageScore}%</p>
        <p>Total Time Spent: ${analyticsData.timeSpent}</p>
    ;

    // Study Materials
    const materialsContainer = document.getElementById('materials-container');
    const studyMaterials = [
        { title: 'Math Notes', link: '#' },
        { title: 'Science Videos', link: '#' },
        { title: 'History Flashcards', link: '#' }
    ];

    studyMaterials.forEach(material => {
        const materialElement = document.createElement('div');
        materialElement.className = 'material';
        materialElement.innerHTML = <a href="${material.link}">${material.title}</a>;
        materialsContainer.appendChild(materialElement);
    });
});

function startTest(testId) {
    alert(Starting test with ID: ${testId});
}